package org.studyeasy;

public class UserDefined {
	public String Demo() {
		 return "Text from demo method";
	}

}
